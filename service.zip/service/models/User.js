// models/User.js
const pool = require('../config/db'); // 引入数据库连接池
const bcrypt = require('bcryptjs');

const User = {
  // 根据邮箱查找用户
  findByEmail: async (email) => {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM users WHERE email = ?',
        [email]
      );
      return rows[0]; // 如果找到用户，返回用户信息，否则返回 undefined
    } catch (error) {
      console.error('Error finding user by email:', error);
      throw error; // 抛出错误，由上层处理
    }
  },

  // 根据用户名查找用户
  findByUsername: async (username) => {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM users WHERE username = ?',
        [username]
      );
      return rows[0];
    } catch (error) {
      console.error('Error finding user by username:', error);
      throw error;
    }
  },
// 验证用户名和密码
verifyCredentials: async (username, plainPassword) => {
  try {
    // 1. 查找用户
    const [rows] = await pool.execute(
      'SELECT * FROM users WHERE username = ?',
      [username]
    );
    const user = rows[0];
    if (!user) return null;

    // 2. 验证密码
    const isMatch = await bcrypt.compare(plainPassword, user.password);
    if (!isMatch) return null;

    // 3. 验证成功，返回用户基本信息（不含密码）
    return {
      id: user.id,
      username: user.username,
      email: user.email,
    };
  } catch (error) {
    console.error('验证用户信息出错:', error);
    throw error;
  }
},

  // 创建新用户
  create: async (newUser) => {
    const { username, email, password } = newUser;
    try {
      // 1. 哈希密码
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);

      // 2. 将用户插入数据库
      const [result] = await pool.execute(
        'INSERT INTO users (username, email, password) VALUES (?, ?, ?)',
        [username, email, hashedPassword]
      );
      return { id: result.insertId, username, email }; // 返回新创建用户的信息 (不包括密码)
    } catch (error) {
      console.error('Error creating user:', error);
      // 检查是否是唯一约束冲突 (例如 ER_DUP_ENTRY)
      if (error.code === 'ER_DUP_ENTRY') {
        if (error.sqlMessage.includes('email')) {
          throw new Error('Email already exists');
        } else if (error.sqlMessage.includes('username')) {
          throw new Error('Username already exists');
        }
      }
      throw error; // 抛出其他错误
    }
  }
};


module.exports = User;