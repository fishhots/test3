const pool = require('../config/db');

function normalizeUsers(user1, user2) {
    return user1 < user2 ? [user1, user2] : [user2, user1];
}

async function findSession(userA, userB) {
    const [rows] = await pool.query('SELECT * FROM session_keys WHERE user_a = ? AND user_b = ?', [userA, userB]);
    return rows.length > 0 ? rows[0] : null;
}

async function createSession(userA, userB, pubkeyA, pubkeyB) {
    const [result] = await pool.query(
        'INSERT INTO session_keys(user_a, user_b, pubkey_a, pubkey_b) VALUES (?, ?, ?, ?)',
        [userA, userB, pubkeyA, pubkeyB]
    );
    return result.insertId;
}

async function updatePubkey(sessionId, field, pubkey) {
    await pool.query(`UPDATE session_keys SET ${field} = ? WHERE session_id = ?`, [pubkey, sessionId]);
}

async function insertMessage(sessionId, sender, receiver, ciphertext) {
    await pool.query(
        'INSERT INTO encrypted_messages(session_id, sender, receiver, ciphertext) VALUES (?, ?, ?, ?)',
        [sessionId, sender, receiver, ciphertext]
    );
}

async function getUnreadMessages(user) {
    const [rows] = await pool.query(
        'SELECT id, session_id, sender, receiver, ciphertext, created_at FROM encrypted_messages WHERE receiver = ? AND is_read = 0 ORDER BY created_at ASC',
        [user]
    );
    return rows;
}

async function markMessageRead(messageId) {
    await pool.query('UPDATE encrypted_messages SET is_read = 1 WHERE id = ?', [messageId]);
}

module.exports = {
    normalizeUsers,
    findSession,
    createSession,
    updatePubkey,
    insertMessage,
    getUnreadMessages,
    markMessageRead,
};
