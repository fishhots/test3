const db = require('../config/db');

const saveMessage = async (from, to, ciphertext) => {
  const sql = 'INSERT INTO messages (`sender`, `receiver`, `ciphertext`) VALUES (?, ?, ?)';
  const [result] = await db.execute(sql, [from, to, ciphertext]);
  return result.insertId;
};

const getMessagesForUser = async (to) => {
  const sql = 'SELECT * FROM messages WHERE `receiver` = ?';
  const [rows] = await db.execute(sql, [to]);
  return rows;
};

const deleteMessageById = async (id) => {
  const sql = 'DELETE FROM messages WHERE id = ?';
  await db.execute(sql, [id]);
};

module.exports = {
  saveMessage,
  getMessagesForUser,
  deleteMessageById,
};
