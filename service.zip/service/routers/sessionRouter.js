const express = require('express');
const router = express.Router();
const sessionModel = require('../models/sessionModel');

router.post('/key-exchange', async (req, res) => {
    const { user, peerUser, publicKey } = req.body;
    if (!user || !peerUser || !publicKey) return res.status(400).json({ error: '参数缺失' });

    const [userA, userB] = sessionModel.normalizeUsers(user, peerUser);

    try {
        let session = await sessionModel.findSession(userA, userB);

        if (!session) {
            // 新建会话
            const pubkeyA = (user === userA) ? publicKey : null;
            const pubkeyB = (user === userB) ? publicKey : null;
            const sessionId = await sessionModel.createSession(userA, userB, pubkeyA, pubkeyB);

            return res.json({ peerPublicKey: null, sessionId });
        } else {
            // 更新公钥（如有变更）
            let updateField = null;
            if (user === userA && (!session.pubkey_a || session.pubkey_a !== publicKey)) updateField = 'pubkey_a';
            if (user === userB && (!session.pubkey_b || session.pubkey_b !== publicKey)) updateField = 'pubkey_b';

            if (updateField) {
                await sessionModel.updatePubkey(session.session_id, updateField, publicKey);
            }

            const peerPubKey = (user === userA) ? session.pubkey_b : session.pubkey_a;
            return res.json({ peerPublicKey: peerPubKey, sessionId: session.session_id });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '服务器错误' });
    }
});

router.post('/message/send', async (req, res) => {
    const { sessionId, sender, receiver, ciphertext } = req.body;
    if (!sessionId || !sender || !receiver || !ciphertext) return res.status(400).json({ error: '参数缺失' });

    try {
        await sessionModel.insertMessage(sessionId, sender, receiver, ciphertext);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '服务器错误' });
    }
});

router.get('/message/poll', async (req, res) => {
    const user = req.query.user;
    if (!user) return res.status(400).json({ error: '缺少用户参数' });

    try {
        const messages = await sessionModel.getUnreadMessages(user);
        res.json({ messages });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '服务器错误' });
    }
});

router.post('/message/ack', async (req, res) => {
    const { messageId } = req.body;
    if (!messageId) return res.status(400).json({ error: '缺少消息ID' });

    try {
        await sessionModel.markMessageRead(messageId);
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: '服务器错误' });
    }
});

module.exports = router;
