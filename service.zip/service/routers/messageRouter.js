// routers/messageRouter.js

const express = require('express');
const router = express.Router();

let messages = [];
let nextId = 1;

/**
 * 发送加密消息
 * POST /message/send
 */
router.post('/send', (req, res) => {
  const { sender, receiver, ciphertext } = req.body;

  if (!sender || !receiver || !ciphertext) {
    return res.status(400).json({ error: '参数缺失' });
  }

  const message = {
    id: nextId++,
    sender,
    receiver,
    ciphertext,
    created_at: new Date().toISOString(),
    acknowledged: false
  };

  messages.push(message);
  console.log('收到消息:', message);
  res.status(200).json({ success: true });
});

/**
 * 拉取未读消息
 * GET /message/poll?user=username
 */
router.get('/poll', (req, res) => {
  const user = req.query.user;
  if (!user) {
    return res.status(400).json({ error: '缺少 user 参数' });
  }

  const newMessages = messages.filter(m => m.receiver === user && !m.acknowledged);
  res.json(newMessages);
});

/**
 * 消息已读确认
 * POST /message/ack
 */
router.post('/ack', (req, res) => {
  const { messageId } = req.body;

  const msg = messages.find(m => m.id === messageId);
  if (msg) {
    msg.acknowledged = true;
    return res.status(200).json({ success: true });
  }

  return res.status(404).json({ error: '消息未找到' });
});

module.exports = router;
