// routes/auth.js
const express = require('express');
const router = express.Router();
const User = require('../models/User'); // 引入 User 模型
const jwt = require('jsonwebtoken');

// @route   POST api/auth/register
// @desc    Register a new user
// @access  Public
router.post('/register', async (req, res) => {
  const { username, email, password } = req.body;

  // 基本的输入验证
  if (!username || !email || !password) {
    return res.status(400).json({ msg: 'Please enter all fields' });
  }

  if (password.length < 6) {
    return res.status(400).json({ msg: 'Password must be at least 6 characters long' });
  }

  // 简单的邮箱格式验证 (可以使用更复杂的库如 validator.js)
  const emailRegex = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
  if (!emailRegex.test(email)) {
      return res.status(400).json({ msg: 'Please enter a valid email address' });
  }


  try {
    // 1. 检查用户是否已存在 (通过邮箱)
    let user = await User.findByEmail(email);
    if (user) {
      return res.status(400).json({ msg: 'User already exists with this email' });
    }

    // 2. 检查用户名是否已存在
    user = await User.findByUsername(username);
    if (user) {
      return res.status(400).json({ msg: 'Username is already taken' });
    }

    // 3. 创建新用户
    const newUser = {
      username,
      email,
      password,
    };

    const createdUser = await User.create(newUser);

    // 4. 返回成功响应
    res.status(201).json({
      msg: 'User registered successfully',
      user: {
        id: createdUser.id,
        username: createdUser.username,
        email: createdUser.email,
      },
    });

  } catch (err) {
    console.error('Registration error:', err.message);
    if (err.message === 'Email already exists' || err.message === 'Username already exists') {
        return res.status(400).json({ msg: err.message });
    }
    res.status(500).send('Server error');
  }
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ msg: '请输入用户名和密码' });
  }

  try {
    const user = await User.verifyCredentials(username, password);
    if (!user) {
      return res.status(400).json({ msg: '用户名或密码错误' });
    }

    // 简单返回，不用 token
    res.json({
      msg: '登录成功',
      user: {
        id: user._id,
        username: user.username,
        email: user.email
      }
    });

  } catch (err) {
    console.error('登录出错:', err.message);
    res.status(500).json({ msg: '服务器内部错误，请稍后再试' });
  }
});
module.exports = router;