// server.js
const express = require('express');
require('dotenv').config(); // 加载 .env 文件中的环境变量

const app = express();
const messageRouter = require('./routers/messageRouter');

// 初始化中间件
app.use(express.json()); // 解析 JSON 请求体
// 如果使用 body-parser (对于旧版 Express 或特定需求):
// const bodyParser = require('body-parser');
// app.use(bodyParser.json());

// 引入数据库连接 (虽然这里没直接用，但 db.js 会在 User 模型中被调用)
// const pool = require('./config/db'); // 可选，如果 server.js 需要直接访问连接池

// 定义路由
app.use('/api/auth', require('./routers/auth')); // 将认证相关的路由挂载到 /api/auth 路径下
app.use('/message', messageRouter);

app.get('/', (req, res) => res.send('API Running with MySQL'));

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));