// config/db.js
const mysql = require('mysql2/promise'); // 使用 promise 版本的 mysql2
require('dotenv').config(); // 加载 .env 文件中的环境变量

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// 测试连接 (可选)
async function testConnection() {
  try {
    const connection = await pool.getConnection();
    console.log('MySQL Connected...');
    connection.release(); // 释放连接回连接池
  } catch (err) {
    console.error('Error connecting to MySQL:', err.message);
    process.exit(1); // 连接失败则退出
  }
}

testConnection(); // 在启动时测试连接

module.exports = pool;